#include "point3d.h"


//! class point3d constructor
//! 3 dimension point
//!
point3d::point3d(double f, double g, double h)
{

	x = f;
	y = g;
	z = h;
}

//! class point3d constructor
//! 3 dimension point
//!
point3d::point3d()
{}
//! point3d class deconstructor
point3d::~point3d()
{
    //dtor
}
